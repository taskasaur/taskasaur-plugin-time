function instantiate(require){const module={exports:{}};const exports=module.exports;
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/server.ts
var server_exports = {};
__export(server_exports, {
  createBackend: () => createBackend,
  default: () => server_default,
  processSchedules: () => processSchedules
});
module.exports = __toCommonJS(server_exports);
var import_errors2 = require("@taskasaur/platform/core/errors");

// src/schedules.ts
var import_node_crypto = require("node:crypto");
var import_server_host = require("@taskasaur/server-host");
var import_errors = require("@taskasaur/platform/core/errors");
function stableUuid(key) {
  const hash = (0, import_node_crypto.createHash)("sha256").update(key).digest("hex");
  return `${hash.slice(0, 8)}-${hash.slice(8, 12)}-4${hash.slice(13, 16)}-8${hash.slice(17, 20)}-${hash.slice(20, 32)}`;
}
async function createOnce(repo, principal, collection, pluginId, key, data) {
  const id = stableUuid(principal.workspaceId + ":" + key);
  return repo.db.transaction(async (tx) => {
    await tx.query(
      "SELECT id FROM taskasaur.workspaces WHERE id=$1 FOR UPDATE",
      [principal.workspaceId]
    );
    const store = new import_server_host.Repository(tx), existing = await tx.query(
      "SELECT id FROM taskasaur.resources WHERE id=$1",
      [id]
    );
    if (existing.rows.length) return;
    return store.mutate(principal, {
      id: (0, import_node_crypto.randomUUID)(),
      resourceId: id,
      collection,
      pluginId,
      operation: "put",
      baseRevision: 0,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      data
    });
  });
}
async function processSchedules(repo, workspaceId, now = Date.now()) {
  const rows = await repo.db.query(
    "SELECT r.id,r.owner_id,r.collection,r.created_at,c.through FROM taskasaur.resources r JOIN taskasaur.plugins p ON p.workspace_id=r.workspace_id AND p.id=r.plugin_id AND p.enabled LEFT JOIN taskasaur.scheduler_cursors c ON c.resource_id=r.id WHERE r.workspace_id=$1 AND r.deleted_at IS NULL AND r.collection = 'time'",
    [workspaceId]
  );
  for (const row of rows.rows) {
    const actor = {
      workspaceId,
      userId: row.owner_id,
      pluginId: row.collection,
      permissions: []
    };
    try {
      const record = await repo.get(actor, row.id);
      if (row.collection === "time") {
        if (record.data.ended_at || record.data.paused_at || !record.data.target_seconds)
          continue;
        const due = Date.parse(String(record.data.started_at)) + Number(record.data.paused_ms ?? 0) + Number(record.data.target_seconds) * 1e3;
        if (due > now) continue;
        await repo.db.transaction(async (tx) => {
          await tx.query(
            "SELECT id FROM taskasaur.workspaces WHERE id=$1 FOR UPDATE",
            [workspaceId]
          );
          const store = new import_server_host.Repository(tx), fresh = await store.get(actor, row.id);
          if (fresh.data.ended_at || fresh.data.paused_at) return;
          await store.mutate(actor, {
            id: (0, import_node_crypto.randomUUID)(),
            resourceId: row.id,
            pluginId: "time",
            collection: "time",
            operation: "put",
            baseRevision: fresh.revision,
            createdAt: new Date(now).toISOString(),
            data: { ...fresh.data, ended_at: new Date(due).toISOString() }
          });
          await createOnce(
            store,
            actor,
            "notifications",
            "notifications",
            `timer:${row.id}`,
            {
              title: fresh.data.kind === "break" ? "Break finished" : "Focus session finished",
              body: String(fresh.data.title),
              resource_id: row.id,
              dedupe_key: `timer:${row.id}`
            }
          );
        });
        continue;
      }
    } catch (error) {
      await repo.db.query(
        "INSERT INTO taskasaur.scheduler_cursors(resource_id,error) VALUES($1,$2) ON CONFLICT(resource_id) DO UPDATE SET error=EXCLUDED.error",
        [
          row.id,
          error instanceof import_errors.CoreError ? `${error.kind}: ${error.message}` : "Schedule failed"
        ]
      );
    }
  }
}

// src/server.ts
function createBackend(core) {
  return {
    async tick({
      repo,
      workspaceId
    }) {
      await processSchedules(repo, workspaceId);
    },
    async beforeMutation({
      repo,
      principal,
      mutation,
      data,
      schema
    }) {
      const tx = repo.db;
      if (schema.id === "time" && !data.ended_at) {
        const active = await tx.query(
          "SELECT r.id FROM taskasaur.resources r JOIN taskasaur.p_time p ON p.id=r.id WHERE r.workspace_id=$1 AND r.owner_id=$2 AND r.deleted_at IS NULL AND p.ended_at IS NULL AND r.id<>$3",
          [principal.workspaceId, principal.userId, mutation.resourceId]
        );
        (0, import_errors2.invariant)(
          !active.rows.length,
          "TIMER_ALREADY_RUNNING",
          "Stop the active timer before starting another"
        );
      }
    }
  };
}
var server_default = {
  async activate(context) {
    const core = context.services.require("core.server");
    const backend = createBackend(core);
    return backend.activate?.(context);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createBackend,
  processSchedules
});

return module.exports;}
export function createBackend(core){return instantiate(core.require).createBackend(core);}
export function loadForHost(core){return instantiate(core.require);}
export default {async activate(context){const core=context.services.require("core.server");const imported=instantiate(core.require);return imported.default?.activate?.(context);}};
